function makeHeaderProperties() {
	properties.put("detailsId", "org.openscada.sample.client.configuration.details.node");
	// properties.put("maintenancePrefix", maintenancePrefix());
	properties.put("sumItem", prefixed("SUM.V"));
}